import React from 'react';
import {Link} from 'react-router-dom';

export const Config = () => {
  return (
    <div>
      配置页面
      <Link to="/">返回首页</Link>
    </div>
  );
};
