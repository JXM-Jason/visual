import React from 'react';
import './home.scss';

export const Home = () => {
  return (
    <div>
      你好
    </div>
  );
};
